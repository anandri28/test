var mainApp = angular.module("mainApp", ['ngRoute']);

mainApp.config(function($routeProvider) {
	$routeProvider
		.when('/home', {
			templateUrl: 'home.html',
			controller: 'UserController'
		})
		.when('/user_dtls/:id', {
			templateUrl: 'user_dtls.html',
			controller: 'UserController'
		})
		.otherwise({
			redirectTo: '/home'
		});
});

mainApp.controller('UserController', function($scope,$http,$routeParams) {
  
  
  
	// GET all user details
	
  $scope.userid = $routeParams.id;
   $scope.uesrdetails = {};
    $scope.todoList = {};
  
	 $http({
      method: 'GET',
      url: 'https://jsonplaceholder.typicode.com/users'
      
  }).then(function (response) {
    
     $scope.uesrdetails = response.data;
    
     
  });
  
  //GET current user
  
  $http({
      method: 'GET',
      url: 'http://jsonplaceholder.typicode.com/todos/'+$scope.userid,
      
  }).then(function (response) {
    
     $scope.todoList = response.data;
    
     
  });
  
  
  
  //Add Todo List
   $scope.todoList = [];

    $scope.todoAdd = function() {
        $scope.todoList.push({todoText:$scope.todoInput, done:false});
        $scope.todoInput = "";
    };
   // Remove Todo List
   $scope.remove = function() {
      var oldList = $scope.todoList;
      $scope.todoList = [];
      angular.forEach(oldList, function(x) {
          if (!x.done) $scope.todoList.push(x);
  });
    
    };
  
});